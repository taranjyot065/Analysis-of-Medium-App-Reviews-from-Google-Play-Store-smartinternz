import pandas as pd
import pickle
import re
import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer

# Download required NLTK data
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

# Preprocessing functions
stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()

def clean_text(text):
    text = text.lower()
    text = re.sub(r'#', '', text)
    text = re.sub(r'[^a-zA-Z ]', '', text)
    return text

def preprocess_text_series(text_series):
    cleaned_sequence = []
    for text in text_series:
        text = clean_text(text)
        tokens = word_tokenize(text)
        filtered_tokens = [lemmatizer.lemmatize(word) for word in tokens if word not in stop_words]
        cleaned_sequence.append(' '.join(filtered_tokens))
    return cleaned_sequence

# Load dataset
df = pd.read_csv('../extracted_archive/dataset.csv')

# Preprocess text
df['text'] = preprocess_text_series(df['text'])

# Vectorize text
tfidf = TfidfVectorizer()
X = tfidf.fit_transform(df['text'])
y = df['label']

# Train model
model = MultinomialNB()
model.fit(X, y)

# Save model and vectorizer
with open('../disClassifier.pkl', 'wb') as model_file:
    pickle.dump(model, model_file)

with open('../tfidf.pkl', 'wb') as tfidf_file:
    pickle.dump(tfidf, tfidf_file)
